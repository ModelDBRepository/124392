#!/usr/bin/env python
import os, sys
from math import log
from interface import *
fixpath()
from p3 import *


f = open('x_%d' % communicator.rank, 'w')

for i in range(1000000):
    f.write('%g\n' % rand_flat())

