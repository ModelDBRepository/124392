import sys
sys.path.append('C:\Documents and Settings\evan\My Documents\Visual Studio Projects\parplex\\Debug')

from _p3 import *

print 'Starting'
#--------------------------------------------------
print 'A new Cell'
c = Cell()
print 'c =', c
#--------------------------------------------------
c.APthreshold = -42
print 'c.APthreshold =', c.APthreshold
#--------------------------------------------------
print 'Try assigning to readonly attributes'
try:
    c.time = 12
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
print 'Inheiratance test'
class Boob(Cell):
    pass
    
b = Boob()
b.noddy = 'Heir to the groan'
b.APthreshold = -42
print b
print 'b.noddy =', b.noddy
print 'b.APthreshold =', b.APthreshold
#--------------------------------------------------
print 'Synapse construction testing'
try:
    s = Synapse()
except TypeError:
    print 's = Synapse()'
    print sys.exc_info()[0], ':', sys.exc_info()[1]
try:
    s = Synapse(b)
except TypeError:
    print 's = Synapse(b)'
    print sys.exc_info()[0], ':', sys.exc_info()[1]
s = Synapse(b,Dynamics(b))
print 's =', s, 's.owner =', s.owner, 's.target =', s.target, 's.target_dynamics =', s.target_dynamics
#--------------------------------------------------
s.ap_delta = 0.3
print 's.ap_delta =', s.ap_delta, 's.strength =', s.strength
#--------------------------------------------------
print 'Try assigning to readonly attributes'
try:
    s.strength = 12
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
print 'b.dynamics =', b.dynamics, 'b.synapse =', b.synapse
del s
print 'b.dynamics =', b.dynamics, 'b.synapse =', b.synapse
del b
#--------------------------------------------------
print 'Exit and object destruction'


