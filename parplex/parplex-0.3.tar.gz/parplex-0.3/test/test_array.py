import sys
sys.path.append('C:\Documents and Settings\evan\My Documents\Visual Studio Projects\parplex\\Debug')

from _p3 import *
print 'Starting'

#--------------------------------------------------
print 'A new array with no initial data'
x = DoubleArray()
print 'x =', x
#--------------------------------------------------
print 'deleting object'
del x
#--------------------------------------------------
print 'Allocating array with initial pure float data'
y = DoubleArray([1.2, 3.4])
#--------------------------------------------------
print "checking it's length"
print 'len(y) =', len(y)
#--------------------------------------------------    
print 'deleting it'
del y
#--------------------------------------------------
print 'Allocating array with mixed numeric data'
z = DoubleArray([1.2, 3])
#--------------------------------------------------
print 'deleting it'
del z
#--------------------------------------------------
print 'Allocating array with nonnumeric data'
try:
    g = DoubleArray([1.2, 'a'])
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
print 'Allocating with nonlist'
try:
    g = DoubleArray('bum')
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
print 'Various representations'
x = DoubleArray()
print x
x = DoubleArray([1])
print x
x = DoubleArray([1, 2, 3])
print x
#--------------------------------------------------
print 'Concatenation test DoubleArray+DoubleArray'
x = DoubleArray([1, 2])
y = DoubleArray([3, 4])
print x+y
#--------------------------------------------------
print 'Concatenation test DoubleArray+list'
print x + [11, 12]
#--------------------------------------------------
print 'Concatenation test list+DoubleArray'
try:
    print [11, 12] + x
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
print 'Repeat tests'
print 'x*0 =', x*0, '  x*1 =', x*1, '  x*4 =', x*4

print 'Simple indexing'
print 'x[0] =', x[0], '  x[1] =', x[1], '  x[-1] =', x[-1]
try:
    print x[4]
except IndexError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
print 'Slicing'
x = DoubleArray([1, 2, 3, 4, 5, 6]);
print 'x[2:4] =', x[2:4]
#--------------------------------------------------
print 'Item assignment'
x[0] = 245
print x
try:
    x[234] = 1
except IndexError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
print 'Slice assignment from list'
x[3:4] = [12, 23, 43, 45, 89, 1023]
print 'x[3:4] = [12, 23, 43, 45, 89, 1023] ==>>', x
#--------------------------------------------------
print 'Slice assignment from DoubleArray'
x[3:4] = x
print 'x[3:4] = x ==>>', x
#--------------------------------------------------
print 'Contains'
x = DoubleArray([1, 2, 3, 4, 5, 6])
print '1 in x =', 1 in x, '    31 in x =', 31 in x
#--------------------------------------------------
print 'Delete items'
del x[1]
del x[2:4]
print x
#--------------------------------------------------
print 'Append'
x.append(234567.8)
print x


