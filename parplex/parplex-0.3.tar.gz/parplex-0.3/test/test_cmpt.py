import sys
sys.path.append('C:\Documents and Settings\evan\My Documents\Visual Studio Projects\parplex\\Debug')

from p3 import *

print 'Starting'
#--------------------------------------------------
cl = Cell_C()
print cl
#--------------------------------------------------
print 'Compartment construction testing'
c1 = Compartment(cl)
c2 = Compartment(cl)
c1.connect(c2, 3)
#--------------------------------------------------
print 'Dynamics construction'
d = Dynamics(c2)
print c1, ',', c2
#--------------------------------------------------
print 'Synapse construction'
s = Synapse(c1, d) 
#--------------------------------------------------
print 'Deletion'
del cl, c1, c2, d, s
