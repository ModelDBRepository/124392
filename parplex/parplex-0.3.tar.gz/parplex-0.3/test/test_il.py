import sys
sys.path.append('C:\Documents and Settings\evan\My Documents\Visual Studio Projects\parplex\\Debug')

from _p3 import *

print 'Starting'
#--------------------------------------------------
print 'A new list with no initial data'
x = InternalList("Synapse")
print 'x =', x
#--------------------------------------------------
print 'deleting object'
del x
#--------------------------------------------------
print 'Allocating list with bad parameters'
try:
    y = InternalList([1,2])
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
print 'Allocating list with a list of Synapses'
y = InternalList('Synapse', [Synapse(), Synapse()])
#--------------------------------------------------
print "checking it's length"
print 'len(y) =', len(y)
#--------------------------------------------------    
print 'deleting it'
del y
#--------------------------------------------------
print 'Allocating InternalList with mixed data'
try:
    z = InternalList('Synapse', [Synapse(), Cell()])
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
print 'Allocating with incorrect type'
try:
    g = InternalList('bum')
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
print 'Various representations'
x = InternalList('Synapse', [Synapse(), Synapse()])
print x
#--------------------------------------------------
print 'Concatenation test InternalList+InternalList'
x = InternalList('Synapse', [Synapse(), Synapse()])
y = InternalList('Synapse', [Synapse(), Synapse()])
print x+y
#--------------------------------------------------
print 'Concatenation test InternalList+list'
print x + [Synapse(), Synapse()]
#--------------------------------------------------
print 'Concatenation test list+InternalList'
try:
    print [Synapse(), Synapse()] + x
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
print 'Simple indexing'
x = InternalList('Synapse', [Synapse(), Synapse(), Synapse(), Synapse()])
print 'x[0] =', x[0], '  x[1] =', x[1], '  x[-1] =', x[-1]
try:
    print x[4]
except IndexError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
print 'Slicing'
x = InternalList('Synapse', [Synapse(), Synapse(), Synapse(), Synapse(), Synapse(), Synapse()]);
print 'x[2:4] =', x[2:4]
#--------------------------------------------------
print 'Item assignment'
x[0] = Synapse()
try:
    x[234] = 1
except IndexError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
print 'Slice assignment from list'
x = InternalList('Synapse', [Synapse(), Synapse(), Synapse(), Synapse(), Synapse(), Synapse()]);
print x, len(x)
x[3:4] = [Synapse(), Synapse()]
print 'x[3:4] = [Synapse(), Synapse()] ==>>', x, len(x)
#--------------------------------------------------
print 'Slice assignment from InternalList'
x[3:4] = x
print 'x[3:4] = x ==>>', x, len(x)
#--------------------------------------------------
print 'Slice assignment with deletion'
x[1:10] = [x[3]]
print 'x[1:10] = x ==>>', x, len(x)
#--------------------------------------------------
print 'Contains'
s = Synapse()
#x = InternalList('Synapse', [Synapse(), Synapse(), s, Synapse(), Synapse()])
print 's in x =', s in x, '    Cell() in x =', Cell() in x
#--------------------------------------------------
print 'Delete items'
del x[1]
del x[2:4]
print x
#--------------------------------------------------
print 'Append'
x.append(Synapse())
print x
