import sys
sys.path.append('C:\Documents and Settings\evan\My Documents\Visual Studio Projects\parplex\\Debug')

from _p3 import *
print 'Starting'
#--------------------------------------------------
print 'A new GD'
x = GD()
print 'x =', x
#--------------------------------------------------
print 'deleting object'
del x
#--------------------------------------------------
x = GD()
x.duration = 100
x.tolerance = 1e-3
x.window = 20
try:
    x.mpi_rank = 3
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
print 'printing members:', x.duration, x.tolerance, x.window, x.mpi_rank
#--------------------------------------------------
print 'allocating call backs'
try:
    x.ap_handler = 3
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
def f():
    print 'howdy'
x.ap_handler = f
x.ap_handler()
#--------------------------------------------------
print 'allocating the network'
x.network = [1, 2]
print x.network
try:
    x.network = 12
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
x.network = None
print x.network
#--------------------------------------------------
#--------------------------------------------------
print 'Testing network list homegineaity'
def p(m, stuff):
    print stuff
x.message_handler = p
x.network = [Cell(), Synapse(Cell(), Dynamics(Cell()))]
try:
    parplex(x)
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
c = Cell()
x.network = [Cell(), c, Cell(), Cell(), c]
print 'testing multiple entries in the network list'
try:
    parplex(x)
except AttributeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
print 'Testing connection to a cell not in the list'
c1 = Cell()
c2 = Cell()
Synapse(c1, Dynamics(c2))
x.network = [c1]
parplex(x)