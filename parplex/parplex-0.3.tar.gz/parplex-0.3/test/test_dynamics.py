import sys
sys.path.append('C:\Documents and Settings\evan\My Documents\Visual Studio Projects\parplex\\Debug')

from _p3 import *
print 'Starting base class tests'
#--------------------------------------------------
try:
    d = Dynamics()
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
c = Cell()
d = Dynamics(c)
print 'New dynamics created with cell:', d, c
del d
print c
#--------------------------------------------------
print 'Trying to assign a new owner'
d = Dynamics(c)
try:
    d.owner = Cell()
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
# Check that reference counting is not getting out of hand
for i in range(10):
    z = d.owner
print d, z
del d
#--------------------------------------------------
print 'Starting Python class tests'
d = PyDynamics(c)
print 'A PyDynamics:', d
#--------------------------------------------------
print 'Subclassing a PyDynamics'
class MyPyDynamics_broken(PyDynamics):
    stateVars = ['m', 'n', 0]
    derivVars = ['dmdt', 'dndt', 0]
    def derivs(self, t):
        print 'derivs:', self, 'self.owner =', self.owner
try:
    mypyd = MyPyDynamics_broken(Cell())
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
#--------------------------------------------------
class MyPyDynamics(PyDynamics):
    stateVars = ['m', 'n']
    derivVars = ['dmdt', 'dndt']
    def derivs(self, t):
        print 'derivs:', self, 'self.owner =', self.owner
mypyd = MyPyDynamics(Cell())
print mypyd.__dict__, MyPyDynamics.__dict__
print mypyd.m, mypyd.n
mypyd.m=12; mypyd.n=1.6e-4
try:
    mypyd.n = 's'
except TypeError:
    print sys.exc_info()[0], ':', sys.exc_info()[1]
print mypyd.m, mypyd.n